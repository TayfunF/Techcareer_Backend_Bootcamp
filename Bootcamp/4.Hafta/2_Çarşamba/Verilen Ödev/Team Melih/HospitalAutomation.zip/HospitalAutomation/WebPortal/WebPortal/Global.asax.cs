﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using BusinessLayer;
using PortalDataLayer;

namespace WebPortal
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
           AreaRegistration.RegisterAllAreas();
           RouteConfig.RegisterRoutes(RouteTable.Routes);
            string OMessage;
            TBusinessLayer BusinessLayer = new TBusinessLayer();

            Application["TblOpeningHours"] = BusinessLayer.GetOpeningHours(out OMessage);
            Application["Partners"] = BusinessLayer.GetPartners(out OMessage);
        }
        void Application_End()
        {
            //Uygulama herhangi bir sebepten durduğunda çalışır
        }

        void Session_Start()
        {
            //Kullanıcı istekte bulunduğu an burası çalışır
        }
        void Session_End()
        {
            //Kullanıcı oturumu öldüğünde devreye girer
        }
    }
}