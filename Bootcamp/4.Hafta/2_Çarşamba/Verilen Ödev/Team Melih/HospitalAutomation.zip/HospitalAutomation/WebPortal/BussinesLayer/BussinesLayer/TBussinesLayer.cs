﻿using System;

namespace BussinesLayer
{
    public class TBussinesLayer
    {
    }
}
