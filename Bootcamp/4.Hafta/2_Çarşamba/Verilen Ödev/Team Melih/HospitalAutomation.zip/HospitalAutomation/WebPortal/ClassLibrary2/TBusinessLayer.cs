﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PortalDataLayer;


namespace BusinessLayer
{
    public class TBusinessLayer
    {
        private DbWebPortalEntities Context;
        
        public TBusinessLayer()
        {
            Context = new DbWebPortalEntities();
            
        }

        public bool IsSubscriber(string MailAddress, out string OMessage)
        {
            OMessage = "";
            bool result = false;
            try
            {              
                TblSubscribers Subscriber = (from Subs in Context.TblSubscribers where Subs.MailAddress == MailAddress select Subs).FirstOrDefault();
                if (Subscriber != null)
                {
                    result = true;
                    OMessage = MailAddress + " adresi zaten kayıt edilmiş.";
                }
            }
            catch (Exception ex)
            {
                OMessage = ex.Message;
            }
            return result;
        }

        public bool AddSubscriber(string MailAddress, out string OMessage)
        {
            OMessage = "";
            bool result = false;
            try
            {
                TblSubscribers NewSubscriber = new TblSubscribers();
                NewSubscriber.MailAddress = MailAddress;
                Context.TblSubscribers.Add(NewSubscriber);
                Context.SaveChanges();
                OMessage = MailAddress + " adresi kayıt edildi";
                result = true;
            }
            catch (Exception ex)
            {
                OMessage = ex.Message;
            }
            return result;
        }

        public bool RemoveSubscriber(string MailAddress, out string OMessage)
        {
            OMessage = "";
            bool result = false;
            try
            {
                TblSubscribers Subscriber = (from Subs in Context.TblSubscribers where Subs.MailAddress == MailAddress select Subs).FirstOrDefault();
                Context.TblSubscribers.Remove(Subscriber);
                Context.SaveChanges();
                OMessage =MailAddress + " adresi abonelikten çıkarıldı";
                result = true;
            }
            catch (Exception ex)
            {
                OMessage = ex.Message;
            }
            return result;
        }       

        public List<TblPartners>GetPartners(out string OMessage)
        {
            List<TblPartners> Partners = new List<TblPartners>();
            OMessage = "";
            try
            {
                Partners = (from DataList in Context.TblPartners select DataList).ToList();
            }
            catch (Exception ex)
            {
                OMessage = ex.Message;
            }
            
            return Partners;
        }
        public List<VWOpeningHours>GetOpeningHours(out string OMessage)
        {
            List<VWOpeningHours> list = new List<VWOpeningHours>();
            OMessage = "";
            try
            {
                list = (from DataList in Context.VWOpeningHours where DataList.Active==true orderby DataList.DayOfWeek ascending select DataList).ToList();
            }
            catch (Exception ex)
            {

                OMessage= ex.Message;
            }
            return list;
        }
        public List<TblDoctors> GetDoctors(out string OMessage)
        {
            List<TblDoctors> Doctors = new List<TblDoctors>();
            OMessage = "";
            try
            {
                Doctors = (from DataTable in Context.TblDoctors where DataTable.Active==true orderby DataTable.NameSurname ascending select DataTable).ToList();
            }
            catch (Exception ex)
            {

                OMessage=ex.Message;
            }
            return Doctors;
        }
        public bool AddAppointment(TblApointment Apointment,out string OMessage)
        {
            bool result = false;
            OMessage = "";
            try
            {
                Context.TblApointment.Add(Apointment);
                Context.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {

                OMessage = ex.Message;
            }

            return result;
        }
    }
}
