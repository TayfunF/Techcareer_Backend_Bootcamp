﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BusinessLayer;
using PortalDataLayer;

namespace WebPortal.Controllers
{
    public class HomeController : Controller
    {
        TBusinessLayer BusinessLayer;
        // GET: Home
        public ActionResult Index()
        {
            string OMessage;

            BusinessLayer = new TBusinessLayer();
            ViewBag.DoctorList = BusinessLayer.GetDoctors(out OMessage);
            //ViewBag.Partners = BusinessLayer.GetPartners(out OMessage);

            return View();

        }
        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult GetAppointment()
        {
            string OMessage;
            BusinessLayer = new TBusinessLayer();
            TblApointment Apointment = new TblApointment();
            Apointment.NameSurname = Request.Form["TxtNameSurname"].ToString();
            Apointment.Email = Request.Form["TxtEmail"].ToString();
            Apointment.PhoneNumber = Request.Form["TxtPhoneNumber"].ToString();
            Apointment.ApointmentDate = Convert.ToDateTime(Request.Form["TxtApointmentDate"].ToString());
            Apointment.DoctorId = Convert.ToInt32(Request.Form["TxtDoctor"]);
                     
            bool Success = BusinessLayer.AddAppointment(Apointment,out OMessage);

            TempData["Success"]=Success;
            TempData["Message"]=OMessage;   

            return new RedirectResult("~/Home");
        }

        public ActionResult AddRemoveSubscriber()
        {
            string OMessage;
            bool Success = false;

            string MailAddress = Request.Form["Email"].ToString();
            string Buton = Request.Form["Button"].ToString();

            try
            {
                TBusinessLayer BusinessLayer = new TBusinessLayer();
                bool IsSubs = BusinessLayer.IsSubscriber(MailAddress, out OMessage);
                if (Buton == "Add")  // Addbutton is clicked
                {
                    if (IsSubs)         // If the mail address is already subscribed
                    {
                        OMessage = MailAddress + " adresi zaten kayıt edilmiş.";
                        Success = false;
                    }
                    else if (!IsSubs)
                        Success = BusinessLayer.AddSubscriber(MailAddress, out OMessage);
                }
                else if (Buton == "Remove") // Removebutton is clicked
                {
                    if (!IsSubs)         // If the mail address isn't a subscriber
                    {
                        OMessage = MailAddress + " adresi zaten kayıtlı değil.";
                        Success = false;
                    }
                    else if (IsSubs)
                        Success = BusinessLayer.RemoveSubscriber(MailAddress, out OMessage);
                }
            }
            catch (Exception ex)
            {
                OMessage = ex.Message;
            }
            TempData["Succes"] = Success;
            TempData["OMessage"] = OMessage;        

            return new RedirectResult("~/Home");
        }

    }
}