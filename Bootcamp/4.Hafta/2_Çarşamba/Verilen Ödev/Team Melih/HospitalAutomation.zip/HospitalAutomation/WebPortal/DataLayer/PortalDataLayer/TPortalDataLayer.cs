﻿using System;

namespace PortalDataLayer
{
    public class TPortalDataLayer
    {
    }
}
